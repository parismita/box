/*
 * Copyright (C) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package com.example.asus.box;

import android.app.Activity;
import android.media.MediaPlayer;
import android.widget.MediaController;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.VideoView;


/*
 * MainActivity class that loads MainFragment
 */
public class MainActivity extends Activity {
    /**
     * Called when the activity is first created.
     */

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //to play video
        VideoView myVideoView = (VideoView) findViewById(R.id.video1);
        myVideoView.setVideoPath("http://172.16.48.144/abc.mp4");
        myVideoView.setMediaController(new MediaController(this));
        myVideoView.setMediaController(null);//to disable video controller
        myVideoView.start();
        //to repeat the video in a loop
        myVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
            }
        });

        /*
        ImageView iview= (ImageView) findViewById(R.id.ig1);
        iview.setImageBitmap(BitmapFactory.decodeFile("http://192.168.43.133/android/a.png"));
        */

        //to display image from server using webview
        WebView myWebView1 = (WebView) findViewById(R.id.web1);
        myWebView1.getSettings().setLoadWithOverviewMode(true);
        myWebView1.getSettings().setUseWideViewPort(true);
        myWebView1.setWebViewClient(new WebViewClient());
        myWebView1.setInitialScale(1);
        myWebView1.loadUrl("http://172.16.48.144/image.png");

        /*
        Bitmap bitmapImage = BitmapFactory.decodeFile("http://192.168.43.133/android/a.png");
        int nh=(int) (bitmapImage.getHeight()*(512.0/bitmapImage.getWidth()));
        Bitmap scaled=Bitmap.createScaledBitmap(bitmapImage,512,nh,true);
        */


        //to open a URL
        WebView myWebView2 = (WebView) findViewById(R.id.web2);
        myWebView2.setWebViewClient(new WebViewClient());
        myWebView2.loadUrl("https://www.google.com");

        //To display a text
        WebView myWebView3 = (WebView) findViewById(R.id.web3);
        myWebView3.setWebViewClient(new WebViewClient());
        myWebView3.loadUrl("http://172.16.48.144/a.html");
    }
}
